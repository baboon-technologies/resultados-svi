import Image from 'next/image';

interface HeaderProps {
  month: string;
  year: string;
  title: string;
  subtitle: string;
}

export function Header({ month, year, title, subtitle }: HeaderProps) {
  return (
    <div className="flex items-start justify-between mb-8">
      <div className="flex-1">
        <div className="mb-2">
          <div className="inline-block bg-blue-50 px-4 py-1 border-l-4 transition-all duration-300" style={{ borderColor: 'var(--svi-primary)' }}>
            <p className="text-lg font-semibold" style={{ color: 'var(--svi-dark-gray)' }}>{month} {year}</p>
          </div>
        </div>
        <h1 className="text-3xl font-bold mb-2 tracking-tight transition-all duration-300" style={{ color: 'var(--svi-primary)' }}>
          {title}
        </h1>
        <p className="text-xl font-semibold transition-colors duration-300" style={{ color: 'var(--svi-secondary)' }}>{subtitle}</p>
      </div>
      <div className="ml-8 transition-transform duration-300 hover:scale-105">
        <Image src="/image.png" alt="SVI - Systematic Value Investing" width={120} height={60} className="transition-opacity duration-300 hover:opacity-90" />
      </div>
    </div>
  );
}
