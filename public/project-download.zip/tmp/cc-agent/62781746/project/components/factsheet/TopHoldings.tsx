interface Holding {
  name: string;
  percentage: string;
}

interface TopHoldingsProps {
  holdings: Holding[];
}

export function TopHoldings({ holdings }: TopHoldingsProps) {
  return (
    <div className="mb-8">
      <div className="bg-blue-50 px-4 py-2 mb-3" style={{ borderLeft: '4px solid var(--svi-primary)' }}>
        <h3 className="text-base font-bold" style={{ color: 'var(--svi-primary)' }}>Top 5 Acciones</h3>
      </div>
      <div className="border overflow-hidden" style={{ borderColor: 'var(--svi-light-gray)' }}>
        {holdings.map((holding, index) => (
          <div
            key={index}
            className={`flex justify-between items-center px-4 py-3 transition-all duration-300 ${
              index !== holdings.length - 1 ? 'border-b' : ''
            }`}
            style={{
              borderColor: 'var(--svi-light-gray)',
              backgroundColor: index % 2 === 0 ? 'white' : '#F9FAFB'
            }}
          >
            <span className="text-sm font-medium" style={{ color: 'var(--svi-dark-gray)' }}>{holding.name}</span>
            <span className="text-sm font-bold" style={{ color: 'var(--svi-primary)' }}>{holding.percentage}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
