import { NextResponse } from 'next/server';

const cache = new Map<string, { data: any; timestamp: number }>();
const CACHE_DURATION = 30000;

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const ticker = searchParams.get('ticker');

  if (!ticker) {
    return NextResponse.json({ error: 'Ticker is required' }, { status: 400 });
  }

  const now = Date.now();
  const cached = cache.get(ticker);

  if (cached && now - cached.timestamp < CACHE_DURATION) {
    return NextResponse.json(cached.data);
  }

  try {
    const response = await fetch(
      `https://query1.finance.yahoo.com/v8/finance/chart/${ticker}`,
      {
        headers: {
          'User-Agent': 'Mozilla/5.0',
        },
      }
    );

    if (!response.ok) {
      throw new Error('Failed to fetch from Yahoo Finance');
    }

    const data = await response.json();
    const result = data.chart.result[0];
    const meta = result.meta;
    const quote = result.indicators.quote[0];

    const currentPrice = meta.regularMarketPrice;
    const previousClose = meta.chartPreviousClose;
    const change = currentPrice - previousClose;
    const changePercent = (change / previousClose) * 100;

    const quoteData = {
      price: currentPrice.toFixed(4),
      change: change.toFixed(4),
      changePercent: changePercent.toFixed(2),
      currency: meta.currency,
      timestamp: new Date().toISOString(),
    };

    cache.set(ticker, { data: quoteData, timestamp: now });

    return NextResponse.json(quoteData);
  } catch (error) {
    if (cached) {
      return NextResponse.json({
        ...cached.data,
        stale: true,
      });
    }

    return NextResponse.json(
      { error: 'No disponible temporalmente' },
      { status: 500 }
    );
  }
}
