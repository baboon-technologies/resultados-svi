import factsheetData from '@/content/factsheet.json';
import { Header } from '@/components/factsheet/Header';
import { RiskScale } from '@/components/factsheet/RiskScale';
import { TwoColumnIntro } from '@/components/factsheet/TwoColumnIntro';
import { TopHoldings } from '@/components/factsheet/TopHoldings';
import { QuarterlyReturnsTable } from '@/components/factsheet/QuarterlyReturnsTable';
import { FundFeatures } from '@/components/factsheet/FundFeatures';
import { DonutChartCard } from '@/components/factsheet/DonutChartCard';
import { DistributorTable } from '@/components/factsheet/DistributorTable';
import { TextSection } from '@/components/factsheet/TextSection';
import { Footer } from '@/components/factsheet/Footer';
import { LiveQuoteCard } from '@/components/factsheet/LiveQuoteCard';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-8 py-12">
        <div className="mb-6 flex justify-end animate-fadeIn">
          <a href="/api/download-pdf">
            <Button className="text-white transition-all duration-300 hover:scale-105 hover:shadow-lg" style={{ backgroundColor: 'var(--svi-primary)' }}>
              <Download className="mr-2 h-4 w-4" />
              Descarga Reporte Completo (PDF)
            </Button>
          </a>
        </div>

        <div className="animate-scaleIn animate-delay-100">
          <LiveQuoteCard ticker={factsheetData.yahooTicker} />
        </div>

        <div className="mt-8">
          <div className="animate-fadeIn animate-delay-200">
            <Header
              month={factsheetData.month}
              year={factsheetData.year}
              title={factsheetData.title}
              subtitle={factsheetData.subtitle}
            />
          </div>

          <div className="animate-slideInLeft animate-delay-300">
            <RiskScale level={factsheetData.riskLevel} />
          </div>

          <div className="animate-fadeIn animate-delay-400">
            <TwoColumnIntro
              description={factsheetData.description}
              investmentObjective={factsheetData.investmentObjective}
            />
          </div>

          <div className="animate-slideInRight animate-delay-500">
            <TopHoldings holdings={factsheetData.topHoldings} />
          </div>

          <div className="animate-scaleIn animate-delay-500">
            <QuarterlyReturnsTable returns={factsheetData.quarterlyReturns} />
          </div>

          <div className="animate-fadeIn animate-delay-500">
            <FundFeatures
              featuresLeft={factsheetData.fundFeaturesLeft}
              featuresRight={factsheetData.fundFeaturesRight}
            />
          </div>
        </div>

        <div className="border-t-4 mt-12 pt-12 animate-fadeIn" style={{ borderColor: 'var(--svi-light-gray)' }}>
          <div className="animate-scaleIn animate-delay-100">
            <DonutChartCard
              title="Inversiones por Sector"
              data={factsheetData.sectorAllocation}
            />
          </div>

          <div className="animate-slideInLeft animate-delay-200">
            <DistributorTable info={factsheetData.distributorInfo} />
          </div>

          <div className="animate-fadeIn animate-delay-300">
            <TextSection
              title={factsheetData.monthlyUpdate.title}
              paragraphs={factsheetData.monthlyUpdate.paragraphs}
            />
          </div>
        </div>

        <div className="border-t-4 mt-12 pt-12 animate-fadeIn" style={{ borderColor: 'var(--svi-light-gray)' }}>
          <div className="animate-slideInRight animate-delay-100">
            <TextSection
              title={factsheetData.importantInfo.title}
              paragraphs={factsheetData.importantInfo.paragraphs}
            />
          </div>

          <div className="animate-fadeIn animate-delay-200">
            <Footer line1={factsheetData.footer.line1} line2={factsheetData.footer.line2} />
          </div>
        </div>

        <div className="mt-8 text-center animate-fadeIn animate-delay-300">
          <a href="/api/download-pdf">
            <Button className="text-white transition-all duration-300 hover:scale-105 hover:shadow-lg" style={{ backgroundColor: 'var(--svi-primary)' }}>
              <Download className="mr-2 h-4 w-4" />
              Descarga Reporte Completo (PDF)
            </Button>
          </a>
        </div>
      </div>
    </main>
  );
}
